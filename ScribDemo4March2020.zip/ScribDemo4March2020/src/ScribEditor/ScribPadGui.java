/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.text.AttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.text.StyledEditorKit;
import javax.swing.KeyStroke;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.Document;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import java.awt.Event;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.JFileChooser;
import javax.swing.text.BadLocationException;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.JOptionPane;
import java.util.StringTokenizer;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;
import javax.swing.text.Style;

/**
 *
 * @author Xi Song
 */
public class ScribPadGui extends javax.swing.JFrame {

    //Undo and redo
    private Document editDocument;
    protected UndoHandler undoHandler = new UndoHandler();
    protected UndoManager undoManager = new UndoManager();
    private UndoAction undoAction = null;
    private RedoAction redoAction = null;
    
    /**
     * Creates new form ScribPadGui
     */
    String fileName;
    Color clrCrnt;
    public ScribPadGui() {
        initComponents();
        // Start of font styling (Sarmad)
        Dimension layout = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(layout.width/2 - this.getWidth()/2, layout.height/2 - this.getHeight()/2);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        GraphicsEnvironment gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontNames = gEnv.getAvailableFontFamilyNames();
        ComboBoxModel model = new DefaultComboBoxModel(fontNames);
        fontDesign.setModel(model);
        // End of font styling (Sarmad)
        // Start of Bolding, Italicising, Underlining, Strikethrough (Robertson)
        fontBoldMenuItem.addActionListener(new StyledEditorKit.BoldAction());
        fontItalicMenuItem.addActionListener(new StyledEditorKit.ItalicAction());
        fontUnderlineMenuItem.addActionListener(new StyledEditorKit.UnderlineAction());
        fontStrikethroughMenuItem.addActionListener(new StrikethroughAction());
        // End of Bolding, Italicising, Underlining, Strikethrough (Robertson)
        // Start of Uppercase/Lowercase (Robertson)
        lowercaseMenuItem.addActionListener(new LowercaseAction());
        uppercaseMenuItem.addActionListener(new UppercaseAction());
        // End of Uppercase/Lowercase (Robertson)
        // Undo/Redo (Logan)
        editDocument = jTextPane1.getDocument();
        editDocument.addUndoableEditListener(undoHandler);
        
        KeyStroke undoKeystroke = KeyStroke.getKeyStroke(KeyEvent.VK_Z, Event.CTRL_MASK);
        KeyStroke redoKeystroke = KeyStroke.getKeyStroke(KeyEvent.VK_Y, Event.CTRL_MASK);

        undoAction = new UndoAction();
        jTextPane1.getInputMap().put(undoKeystroke, "undoKeystroke");
        jTextPane1.getActionMap().put("undoKeystroke", undoAction);

        redoAction = new RedoAction();
        jTextPane1.getInputMap().put(redoKeystroke, "redoKeystroke");
        jTextPane1.getActionMap().put("redoKeystroke", redoAction);
        // End of Undo/Redo (Logan)
    }
    
    //Begin of "Search function" edited by Xi
    class MyHighlightPainter extends DefaultHighlighter.DefaultHighlightPainter{
          public MyHighlightPainter(Color color){
              super(color);
          }
           
      }
    
        
         Highlighter.HighlightPainter myHighlightPainter = new MyHighlightPainter(Color.yellow);
         
         
         public void removeHighlights(JTextComponent textComp){
             Highlighter hilite = textComp.getHighlighter();
             Highlighter.Highlight[] hilites = hilite.getHighlights();
             
             for(int i=0; i<hilites.length;i++){
                 if(hilites[i].getPainter() instanceof MyHighlightPainter){
                     hilite.removeHighlight(hilites[i]);
                 }
             }
         }
         
         public void highlight(JTextComponent textComp, String pattern){
             
             removeHighlights(textComp);
             
             try{
                 
                 Highlighter hilite = textComp.getHighlighter();
                 Document doc =textComp.getDocument();
                 String text = doc.getText(0, doc.getLength());
                 int pos=0;
                 
                 while((pos=text.toUpperCase().indexOf(pattern.toUpperCase(),pos))>=0){
                     hilite.addHighlight(pos, pos+pattern.length(), myHighlightPainter);
                     pos += pattern.length();
                 }
             }
             catch(Exception e){
                 
             }
             
         }
         //End of "Search Function" edited by Xi

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        quickToolBar = new javax.swing.JToolBar();
        newFileQuickButton = new javax.swing.JButton();
        openFileQuickButton = new javax.swing.JButton();
        saveFileQuickButton = new javax.swing.JButton();
        copyTextQuickButton = new javax.swing.JButton();
        cutTextQuickButton = new javax.swing.JButton();
        pasteTextQuickButton = new javax.swing.JButton();
        highlightQuickButton = new javax.swing.JButton();
        changeColorQuickBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        fontDesign = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        fontSize = new javax.swing.JComboBox<>();
        searchButtonItem = new javax.swing.JButton();
        searchTextfield = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        newFile = new javax.swing.JMenuItem();
        openFile = new javax.swing.JMenuItem();
        saveFile = new javax.swing.JMenuItem();
        saveAsFile = new javax.swing.JMenuItem();
        PrintFile = new javax.swing.JMenuItem();
        exitFile = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        undoMenuItem = new javax.swing.JMenuItem();
        redoMenuItem = new javax.swing.JMenuItem();
        cutText = new javax.swing.JMenuItem();
        copyText = new javax.swing.JMenuItem();
        pasteText = new javax.swing.JMenuItem();
        searchMenu = new javax.swing.JMenu();
        findChar = new javax.swing.JMenuItem();
        findNextChar = new javax.swing.JMenuItem();
        findPreChar = new javax.swing.JMenuItem();
        replaceText = new javax.swing.JMenuItem();
        insertMenu = new javax.swing.JMenu();
        formatMenu = new javax.swing.JMenu();
        fontEditMenu = new javax.swing.JMenu();
        fontSizeMenuItem = new javax.swing.JMenu();
        increaseFontSize = new javax.swing.JMenuItem();
        decreaseFontSize = new javax.swing.JMenuItem();
        fontBoldMenuItem = new javax.swing.JMenuItem();
        fontItalicMenuItem = new javax.swing.JMenuItem();
        fontUnderlineMenuItem = new javax.swing.JMenuItem();
        fontStrikethroughMenuItem = new javax.swing.JMenuItem();
        capitalizationMenu = new javax.swing.JMenu();
        lowercaseMenuItem = new javax.swing.JMenuItem();
        uppercaseMenuItem = new javax.swing.JMenuItem();
        indentMenu = new javax.swing.JMenu();
        increaseIndentMenuItem = new javax.swing.JMenuItem();
        decreaseIndentMenuItem = new javax.swing.JMenuItem();
        lineSpacingMenu = new javax.swing.JMenu();
        lineSpacingSing = new javax.swing.JMenuItem();
        lineSpacingDoub = new javax.swing.JMenuItem();
        toolMenu = new javax.swing.JMenu();
        wordCounterMenuItem = new javax.swing.JMenuItem();
        jMenuItem17 = new javax.swing.JMenuItem();
        jMenuItem18 = new javax.swing.JMenuItem();
        settingMenu = new javax.swing.JMenu();
        fontColorMenu = new javax.swing.JMenu();
        fontHighlightColorMenuItem = new javax.swing.JMenuItem();
        jMenuItem19 = new javax.swing.JMenuItem();
        jMenuItem20 = new javax.swing.JMenuItem();
        jMenuItem21 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        quickToolBar.setRollover(true);
        quickToolBar.setAlignmentY(0.5F);

        newFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/newFile1.png"))); // NOI18N
        newFileQuickButton.setToolTipText("New");
        newFileQuickButton.setFocusable(false);
        newFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        newFileQuickButton.setMaximumSize(new java.awt.Dimension(30, 40));
        newFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        newFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(newFileQuickButton);

        openFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/document_open.png"))); // NOI18N
        openFileQuickButton.setToolTipText("Open");
        openFileQuickButton.setFocusable(false);
        openFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        openFileQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        openFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        openFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(openFileQuickButton);

        saveFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/save_file.png"))); // NOI18N
        saveFileQuickButton.setToolTipText("Save");
        saveFileQuickButton.setFocusable(false);
        saveFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveFileQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        saveFileQuickButton.setMinimumSize(new java.awt.Dimension(39, 39));
        saveFileQuickButton.setPreferredSize(new java.awt.Dimension(35, 35));
        saveFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        saveFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(saveFileQuickButton);

        copyTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/copy.png"))); // NOI18N
        copyTextQuickButton.setToolTipText("Copy");
        copyTextQuickButton.setFocusable(false);
        copyTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        copyTextQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        copyTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        copyTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(copyTextQuickButton);

        cutTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/clipboard_cut.png"))); // NOI18N
        cutTextQuickButton.setToolTipText("Cut");
        cutTextQuickButton.setFocusable(false);
        cutTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cutTextQuickButton.setMaximumSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setMinimumSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setPreferredSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cutTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(cutTextQuickButton);

        pasteTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/paste.png"))); // NOI18N
        pasteTextQuickButton.setToolTipText("Paste");
        pasteTextQuickButton.setFocusable(false);
        pasteTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        pasteTextQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        pasteTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        pasteTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(pasteTextQuickButton);

        highlightQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/highlight (1).png"))); // NOI18N
        highlightQuickButton.setToolTipText("Highlight");
        highlightQuickButton.setFocusable(false);
        highlightQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        highlightQuickButton.setMaximumSize(new java.awt.Dimension(39, 39));
        highlightQuickButton.setMinimumSize(new java.awt.Dimension(39, 39));
        highlightQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(highlightQuickButton);

        changeColorQuickBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/color.png"))); // NOI18N
        changeColorQuickBtn.setToolTipText("Change Text Color");
        changeColorQuickBtn.setFocusable(false);
        changeColorQuickBtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        changeColorQuickBtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        changeColorQuickBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeColorQuickBtnActionPerformed(evt);
            }
        });
        quickToolBar.add(changeColorQuickBtn);

        jLabel1.setText("Font");
        quickToolBar.add(jLabel1);

        fontDesign.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        fontDesign.setMinimumSize(new java.awt.Dimension(40, 20));
        fontDesign.setPreferredSize(new java.awt.Dimension(40, 20));
        fontDesign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontDesignActionPerformed(evt);
            }
        });
        quickToolBar.add(fontDesign);

        jLabel2.setText("Size");
        quickToolBar.add(jLabel2);

        fontSize.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "12", "16", "20", "24", "28", "32", "36", "40", "44", "48", "52", "56", "60", "64", "68", "72" }));
        fontSize.setToolTipText("Text Size");
        fontSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontSizeActionPerformed(evt);
            }
        });
        quickToolBar.add(fontSize);

        searchButtonItem.setText("Search");
        searchButtonItem.setFocusable(false);
        searchButtonItem.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        searchButtonItem.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        searchButtonItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonItemActionPerformed(evt);
            }
        });
        quickToolBar.add(searchButtonItem);

        searchTextfield.setMaximumSize(new java.awt.Dimension(80000, 500));
        quickToolBar.add(searchTextfield);

        jScrollPane1.setViewportView(jTextPane1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(quickToolBar, javax.swing.GroupLayout.DEFAULT_SIZE, 737, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(quickToolBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE))
        );

        fileMenu.setText("File");

        newFile.setText("New");
        newFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileActionPerformed(evt);
            }
        });
        fileMenu.add(newFile);

        openFile.setText("Open");
        openFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileActionPerformed(evt);
            }
        });
        fileMenu.add(openFile);

        saveFile.setText("Save");
        saveFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveFile);

        saveAsFile.setText("Save As");
        saveAsFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveAsFile);

        PrintFile.setText("Print");
        fileMenu.add(PrintFile);

        exitFile.setText("Exit");
        exitFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitFileActionPerformed(evt);
            }
        });
        fileMenu.add(exitFile);

        jMenuBar1.add(fileMenu);

        editMenu.setText("Edit");

        undoMenuItem.setText("Undo");
        undoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(undoMenuItem);

        redoMenuItem.setText("Redo");
        redoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(redoMenuItem);

        cutText.setText("Cut");
        cutText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextActionPerformed(evt);
            }
        });
        editMenu.add(cutText);

        copyText.setText("Copy");
        copyText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextActionPerformed(evt);
            }
        });
        editMenu.add(copyText);

        pasteText.setText("Paste");
        pasteText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextActionPerformed(evt);
            }
        });
        editMenu.add(pasteText);

        jMenuBar1.add(editMenu);

        searchMenu.setText("Search");

        findChar.setText("Find");
        searchMenu.add(findChar);

        findNextChar.setText("Find Next");
        searchMenu.add(findNextChar);

        findPreChar.setText("Find Previous");
        searchMenu.add(findPreChar);

        replaceText.setText("Replace");
        searchMenu.add(replaceText);

        jMenuBar1.add(searchMenu);

        insertMenu.setText("Insert");
        jMenuBar1.add(insertMenu);

        formatMenu.setText("Format");

        fontEditMenu.setText("Text");

        fontSizeMenuItem.setText("Size");

        increaseFontSize.setText("Increase Font Size");
        fontSizeMenuItem.add(increaseFontSize);

        decreaseFontSize.setText("Decrease Font Size");
        fontSizeMenuItem.add(decreaseFontSize);

        fontEditMenu.add(fontSizeMenuItem);

        fontBoldMenuItem.setText("Bold");
        fontEditMenu.add(fontBoldMenuItem);

        fontItalicMenuItem.setText("Italic");
        fontEditMenu.add(fontItalicMenuItem);

        fontUnderlineMenuItem.setText("Underline");
        fontEditMenu.add(fontUnderlineMenuItem);

        fontStrikethroughMenuItem.setText("Strikethrough");
        fontEditMenu.add(fontStrikethroughMenuItem);

        capitalizationMenu.setText("Capitalization");

        lowercaseMenuItem.setText("lowercase");
        capitalizationMenu.add(lowercaseMenuItem);

        uppercaseMenuItem.setText("UPPERCASE");
        capitalizationMenu.add(uppercaseMenuItem);

        fontEditMenu.add(capitalizationMenu);

        formatMenu.add(fontEditMenu);

        indentMenu.setText("Indent");

        increaseIndentMenuItem.setText("Increase indent");
        indentMenu.add(increaseIndentMenuItem);

        decreaseIndentMenuItem.setText("Decrease indent");
        indentMenu.add(decreaseIndentMenuItem);

        formatMenu.add(indentMenu);

        lineSpacingMenu.setText("Line Spacing");

        lineSpacingSing.setText("Single");
        lineSpacingMenu.add(lineSpacingSing);

        lineSpacingDoub.setText("Double");
        lineSpacingMenu.add(lineSpacingDoub);

        formatMenu.add(lineSpacingMenu);

        jMenuBar1.add(formatMenu);

        toolMenu.setText("Tools");

        wordCounterMenuItem.setText("Word Counter");
        wordCounterMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wordCounterMenuItemActionPerformed(evt);
            }
        });
        toolMenu.add(wordCounterMenuItem);

        jMenuItem17.setText("jMenuItem1");
        toolMenu.add(jMenuItem17);

        jMenuItem18.setText("jMenuItem1");
        toolMenu.add(jMenuItem18);

        jMenuBar1.add(toolMenu);

        settingMenu.setText("Setting");

        fontColorMenu.setText("Color");

        fontHighlightColorMenuItem.setText("Highlight Color");
        fontColorMenu.add(fontHighlightColorMenuItem);

        settingMenu.add(fontColorMenu);

        jMenuItem19.setText("jMenuItem1");
        settingMenu.add(jMenuItem19);

        jMenuItem20.setText("jMenuItem1");
        settingMenu.add(jMenuItem20);

        jMenuItem21.setText("jMenuItem1");
        settingMenu.add(jMenuItem21);

        jMenuBar1.add(settingMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showSaveDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();

            HTMLEditorKit kit = new HTMLEditorKit();

            BufferedOutputStream out;

            try {
                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            } catch (BadLocationException e){

            }
        }
    }//GEN-LAST:event_saveFileActionPerformed

    private void saveFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileQuickButtonActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showSaveDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();

            HTMLEditorKit kit = new HTMLEditorKit();

            BufferedOutputStream out;

            try {
                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            } catch (BadLocationException e){

            }
        }
    }//GEN-LAST:event_saveFileQuickButtonActionPerformed

    private void cutTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextQuickButtonActionPerformed
        //Logan's feature
        jTextPane1.cut();
    }//GEN-LAST:event_cutTextQuickButtonActionPerformed

    private void changeColorQuickBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeColorQuickBtnActionPerformed
        //Sarmad's feature
        int start = jTextPane1.getSelectionStart();
        int end = jTextPane1.getSelectionEnd();
        int selectedLength = end-start;
        StyledDocument style = jTextPane1.getStyledDocument();
        AttributeSet oldset = style.getCharacterElement(end-1).getAttributes();
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet s = sc.addAttribute(oldset, StyleConstants.Foreground, JColorChooser.showDialog(this,"Select Text Color", clrCrnt));
        style.setCharacterAttributes(start, selectedLength, s, true);
    }//GEN-LAST:event_changeColorQuickBtnActionPerformed

    private void fontDesignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontDesignActionPerformed
        //Sarmad's feature
        fontDesign.setFocusable(false);
        String style = new String(fontDesign.getSelectedItem().toString());
        Action action = new StyledEditorKit.FontFamilyAction("Font size", style);
        action.actionPerformed(null);
    }//GEN-LAST:event_fontDesignActionPerformed

    private void fontSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontSizeActionPerformed
        //Sarmad's feature
        fontSize.setFocusable(false);
        Integer value = Integer.parseInt(fontSize.getSelectedItem().toString());
        Action action = new StyledEditorKit.FontSizeAction("Font size", value);
        action.actionPerformed(null);
    }//GEN-LAST:event_fontSizeActionPerformed

    private void newFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileQuickButtonActionPerformed
        //Sarmad's feature
        jTextPane1.setText("");
        setTitle(fileName);
    }//GEN-LAST:event_newFileQuickButtonActionPerformed

    private void newFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileActionPerformed
        //Written by Sarmad
        jTextPane1.setText("");
        setTitle(fileName);
    }//GEN-LAST:event_newFileActionPerformed

    private void copyTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextQuickButtonActionPerformed
        //Logan's feature
        jTextPane1.copy();
    }//GEN-LAST:event_copyTextQuickButtonActionPerformed

    private void pasteTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextQuickButtonActionPerformed
        //Logan's feature
        jTextPane1.paste();
    }//GEN-LAST:event_pasteTextQuickButtonActionPerformed

    private void cutTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextActionPerformed
        //Logan's feature
        jTextPane1.cut();
    }//GEN-LAST:event_cutTextActionPerformed

    private void copyTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextActionPerformed
        //Logan's feature
        jTextPane1.copy();
    }//GEN-LAST:event_copyTextActionPerformed

    private void pasteTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextActionPerformed
        //Logan's feature
        jTextPane1.paste();
    }//GEN-LAST:event_pasteTextActionPerformed

    private void wordCounterMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wordCounterMenuItemActionPerformed
        //Xi's feature
        String text = jTextPane1.getText();
        JOptionPane.showMessageDialog(this,"Total words: "+ new StringTokenizer(text).countTokens()); 
    }//GEN-LAST:event_wordCounterMenuItemActionPerformed

    private void undoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoMenuItemActionPerformed
        //Logan's feature
        undoManager.undo();
    }//GEN-LAST:event_undoMenuItemActionPerformed

    private void redoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoMenuItemActionPerformed
        //Logan's feature
        undoManager.redo();
    }//GEN-LAST:event_redoMenuItemActionPerformed

    private void openFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileQuickButtonActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showOpenDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            File file = chooser.getSelectedFile();

            jTextPane1.setEditorKit(new HTMLEditorKit());

            try {

            FileReader reader = new FileReader(file);

            jTextPane1.read(reader, file);

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            }
        }
    }//GEN-LAST:event_openFileQuickButtonActionPerformed

    private void openFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showOpenDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            File file = chooser.getSelectedFile();

            jTextPane1.setEditorKit(new HTMLEditorKit());

            try {

            FileReader reader = new FileReader(file);

            jTextPane1.read(reader, file);

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            }
        }
    }//GEN-LAST:event_openFileActionPerformed

    private void saveAsFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showSaveDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();

            HTMLEditorKit kit = new HTMLEditorKit();

            BufferedOutputStream out;

            try {
                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            } catch (BadLocationException e){

            }
        }
    }//GEN-LAST:event_saveAsFileActionPerformed

    private void exitFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitFileActionPerformed
        // Julia's feature
        System.exit(0);
    }//GEN-LAST:event_exitFileActionPerformed

    private void searchButtonItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonItemActionPerformed
        if(searchTextfield.getText().equals("")){        
    }
        else
        highlight(jTextPane1, searchTextfield.getText());
        
    }//GEN-LAST:event_searchButtonItemActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScribPadGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem PrintFile;
    private javax.swing.JMenu capitalizationMenu;
    private javax.swing.JButton changeColorQuickBtn;
    private javax.swing.JMenuItem copyText;
    private javax.swing.JButton copyTextQuickButton;
    private javax.swing.JMenuItem cutText;
    private javax.swing.JButton cutTextQuickButton;
    private javax.swing.JMenuItem decreaseFontSize;
    private javax.swing.JMenuItem decreaseIndentMenuItem;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitFile;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenuItem findChar;
    private javax.swing.JMenuItem findNextChar;
    private javax.swing.JMenuItem findPreChar;
    private javax.swing.JMenuItem fontBoldMenuItem;
    private javax.swing.JMenu fontColorMenu;
    private javax.swing.JComboBox<String> fontDesign;
    private javax.swing.JMenu fontEditMenu;
    private javax.swing.JMenuItem fontHighlightColorMenuItem;
    private javax.swing.JMenuItem fontItalicMenuItem;
    private javax.swing.JComboBox<String> fontSize;
    private javax.swing.JMenu fontSizeMenuItem;
    private javax.swing.JMenuItem fontStrikethroughMenuItem;
    private javax.swing.JMenuItem fontUnderlineMenuItem;
    private javax.swing.JMenu formatMenu;
    private javax.swing.JButton highlightQuickButton;
    private javax.swing.JMenuItem increaseFontSize;
    private javax.swing.JMenuItem increaseIndentMenuItem;
    private javax.swing.JMenu indentMenu;
    private javax.swing.JMenu insertMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem17;
    private javax.swing.JMenuItem jMenuItem18;
    private javax.swing.JMenuItem jMenuItem19;
    private javax.swing.JMenuItem jMenuItem20;
    private javax.swing.JMenuItem jMenuItem21;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JMenuItem lineSpacingDoub;
    private javax.swing.JMenu lineSpacingMenu;
    private javax.swing.JMenuItem lineSpacingSing;
    private javax.swing.JMenuItem lowercaseMenuItem;
    private javax.swing.JMenuItem newFile;
    private javax.swing.JButton newFileQuickButton;
    private javax.swing.JMenuItem openFile;
    private javax.swing.JButton openFileQuickButton;
    private javax.swing.JMenuItem pasteText;
    private javax.swing.JButton pasteTextQuickButton;
    private javax.swing.JToolBar quickToolBar;
    private javax.swing.JMenuItem redoMenuItem;
    private javax.swing.JMenuItem replaceText;
    private javax.swing.JMenuItem saveAsFile;
    private javax.swing.JMenuItem saveFile;
    private javax.swing.JButton saveFileQuickButton;
    private javax.swing.JButton searchButtonItem;
    private javax.swing.JMenu searchMenu;
    private javax.swing.JTextField searchTextfield;
    private javax.swing.JMenu settingMenu;
    private javax.swing.JMenu toolMenu;
    private javax.swing.JMenuItem undoMenuItem;
    private javax.swing.JMenuItem uppercaseMenuItem;
    private javax.swing.JMenuItem wordCounterMenuItem;
    // End of variables declaration//GEN-END:variables
    // java undo and redo action classes

    // Logan's classes 
    class UndoHandler implements UndoableEditListener
    {

    /**
    * Messaged when the Document has created an edit, the edit is added to
    * <code>undoManager</code>, an instance of UndoManager.
    */
        @Override
        public void undoableEditHappened(UndoableEditEvent e)
        {
            undoManager.addEdit(e.getEdit());
            undoAction.update();
            redoAction.update();
        }
    }

    class UndoAction extends AbstractAction
    {
        public UndoAction()
        {
            super("Undo");
            setEnabled(false);
        }

        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                undoManager.undo();
            }
            catch (CannotUndoException ex)
            {
                // TODO deal with this
                //ex.printStackTrace();
            }
            
            update();
            redoAction.update();
    }

    protected void update()
    {
        if (undoManager.canUndo())
        {
            setEnabled(true);
            putValue(Action.NAME, undoManager.getUndoPresentationName());
        }
        else
        {
            setEnabled(false);
            putValue(Action.NAME, "Undo");
        }
    }
}

    class RedoAction extends AbstractAction
    {
          public RedoAction()
          {
            super("Redo");
            setEnabled(false);
          }

          @Override
          public void actionPerformed(ActionEvent e)
          {
            try
            {
              undoManager.redo();
            }
            catch (CannotRedoException ex)
            {

            }
            update();
            undoAction.update();
          }

          protected void update()
          {
            if (undoManager.canRedo())
            {
              putValue(Action.NAME, undoManager.getRedoPresentationName());
              setEnabled(true);
            }
            else
            {
              setEnabled(false);
              putValue(Action.NAME, "Redo");
            }
          }
    }
    // End of Logan's classes
}
